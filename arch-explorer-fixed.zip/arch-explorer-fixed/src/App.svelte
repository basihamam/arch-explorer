<script>
  import { onMount } from "svelte";
  import Titlebar from "./lib/components/Titlebar.svelte";
  import Sidebar from "./lib/components/Sidebar.svelte";
  import Toolbar from "./lib/components/Toolbar.svelte";
  import FileGrid from "./lib/components/FileGrid.svelte";
  import StatusBar from "./lib/components/StatusBar.svelte";
  import ContextMenu from "./lib/components/ContextMenu.svelte";
  import Notifications from "./lib/components/Notifications.svelte";
  import MountPanel from "./lib/components/MountPanel.svelte";
  import CommandsPanel from "./lib/components/CommandsPanel.svelte";
  import SettingsPanel from "./lib/components/SettingsPanel.svelte";

  import {
    loadDirectory, loadDrives, loadBookmarks,
    loadUserCommands, currentPath, theme
  } from "./lib/stores/explorer.js";

  let showMounts    = false;
  let showCommands  = false;
  let showSettings  = false;

  onMount(async () => {
    document.documentElement.setAttribute("data-theme", $theme);

    await Promise.all([
      loadBookmarks(),
      loadDrives(),
      loadUserCommands(),
    ]);

    await loadDirectory($currentPath);

    // Global keyboard shortcuts
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  });

  function handleKey(e) {
    if (e.key === "F5")                              loadDirectory($currentPath);
    if (e.altKey && e.key === "ArrowLeft")           import("./lib/stores/explorer.js").then(m => m.navigateBack());
    if (e.altKey && e.key === "ArrowRight")          import("./lib/stores/explorer.js").then(m => m.navigateForward());
    if (e.altKey && e.key === "ArrowUp")             import("./lib/stores/explorer.js").then(m => m.navigateUp());
    if (e.ctrlKey && e.key === "h")                  import("./lib/stores/explorer.js").then(m => m.showHidden.update(v => !v) && loadDirectory($currentPath));
  }
</script>

<!-- Prevent text selection globally -->
<svelte:body on:selectstart|preventDefault />

<div class="app-shell glass">
  <Titlebar
    on:mounts={()   => showMounts   = !showMounts}
    on:commands={() => showCommands = !showCommands}
    on:settings={() => showSettings = !showSettings}
  />

  <div class="main-area">
    <Sidebar />
    <div class="content-area">
      <Toolbar />
      <FileGrid />
      <StatusBar />
    </div>
  </div>

  <!-- Always-present overlays -->
  <ContextMenu />
  <Notifications />

  {#if showMounts}
    <MountPanel on:close={() => showMounts = false} />
  {/if}
  {#if showCommands}
    <CommandsPanel on:close={() => showCommands = false} />
  {/if}
  {#if showSettings}
    <SettingsPanel on:close={() => showSettings = false} />
  {/if}
</div>

<style>
  /* Tüm uygulamada yazı seçimini kapat */
  :global(*) {
    user-select: none;
    -webkit-user-select: none;
  }
  /* Sadece input'larda açık kalsın */
  :global(input), :global(textarea) {
    user-select: text;
    -webkit-user-select: text;
  }

  .app-shell {
    width: 100vw;
    height: 100vh;
    display: flex;
    flex-direction: column;
    border-radius: var(--radius-lg);
    overflow: hidden;
    border: 1px solid var(--border);
    box-shadow: 0 32px 64px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04);
  }

  .main-area {
    display: flex;
    flex: 1;
    overflow: hidden;
  }

  .content-area {
    display: flex;
    flex-direction: column;
    flex: 1;
    overflow: hidden;
  }
</style>
