<script>
  import { createEventDispatcher, onMount } from "svelte";
  import { invoke } from "@tauri-apps/api/core";
  import { notify, navigateTo } from "../stores/explorer.js";

  const dispatch = createEventDispatcher();

  let devices = [];
  let loading = false;
  let mounting = null;

  onMount(loadDevices);

  async function loadDevices() {
    loading = true;
    try {
      devices = await invoke("list_block_devices");
    } catch (e) {
      notify("error", String(e));
    } finally {
      loading = false;
    }
  }

  async function mount(dev) {
    mounting = dev.device;
    try {
      let result;
      if (dev.is_windows) {
        result = await invoke("mount_ntfs_windows_disk", { device: dev.device, mountPoint: null });
      } else {
        result = await invoke("mount_device", { device: dev.device });
      }
      notify("success", result.message || "Mounted!");
      if (result.mount_point) navigateTo(result.mount_point);
      await loadDevices();
    } catch (e) {
      notify("error", String(e));
    } finally {
      mounting = null;
    }
  }

  async function unmount(dev) {
    mounting = dev.device;
    try {
      const msg = await invoke("unmount_device", { device: dev.device });
      notify("success", msg || "Unmounted");
      await loadDevices();
    } catch (e) {
      notify("error", String(e));
    } finally {
      mounting = null;
    }
  }

  function open(dev) {
    if (dev.mount_point) navigateTo(dev.mount_point);
    dispatch("close");
  }
</script>

<div class="overlay" on:click|self={() => dispatch("close")}>
  <div class="panel glass">
    <div class="panel-header">
      <span>Disks & Mounts</span>
      <button on:click={() => dispatch("close")}>✕</button>
    </div>

    {#if loading}
      <div class="loading">Scanning devices...</div>
    {:else}
      <div class="device-list">
        {#each devices as dev}
          <div class="device-row" class:mounted={dev.is_mounted}>
            <div class="dev-info">
              <span class="dev-icon">{dev.is_windows ? "🪟" : dev.is_mounted ? "💿" : "⬡"}</span>
              <div class="dev-meta">
                <span class="dev-name">{dev.label || dev.name}</span>
                <span class="dev-detail">{dev.device} · {dev.fs_type} · {dev.size}</span>
                {#if dev.mount_point}
                  <span class="dev-mount">{dev.mount_point}</span>
                {/if}
                {#if dev.is_windows}
                  <span class="win-badge">Windows NTFS</span>
                {/if}
              </div>
            </div>
            <div class="dev-actions">
              {#if dev.is_mounted}
                <button class="btn" on:click={() => open(dev)}>Open</button>
                <button class="btn btn-danger" on:click={() => unmount(dev)}
                  disabled={mounting === dev.device}>
                  {mounting === dev.device ? "..." : "Unmount"}
                </button>
              {:else}
                <button class="btn btn-accent" on:click={() => mount(dev)}
                  disabled={mounting === dev.device}>
                  {mounting === dev.device ? "Mounting..." : dev.is_windows ? "Mount (NTFS Fix)" : "Mount"}
                </button>
              {/if}
            </div>
          </div>
        {/each}

        {#if devices.length === 0}
          <div class="empty">No block devices found</div>
        {/if}
      </div>

      <!-- NTFS tip -->
      <div class="tip">
        <strong>Windows disk not working?</strong> "Mount (NTFS Fix)" automatically applies
        <code>uid/gid</code> permissions and handles hibernation errors.
        Make sure <code>ntfs-3g</code> is installed:
        <code>sudo pacman -S ntfs-3g</code>
      </div>
    {/if}

    <div class="panel-footer">
      <button class="btn" on:click={loadDevices}>↻ Refresh</button>
    </div>
  </div>
</div>

<style>
  .overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.4);
    backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 100;
  }
  .panel {
    width: 560px;
    max-height: 70vh;
    border-radius: var(--radius-lg);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .panel-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 18px;
    border-bottom: 1px solid var(--border);
    font-weight: 600;
  }
  .panel-header button {
    background: none; border: none;
    color: var(--text-dim); cursor: pointer; font-size: 14px;
  }
  .device-list { flex: 1; overflow-y: auto; padding: 10px; display: flex; flex-direction: column; gap: 6px; }
  .device-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 12px;
    border-radius: var(--radius);
    border: 1px solid var(--border);
    background: var(--bg-tertiary);
    gap: 12px;
  }
  .device-row.mounted { border-color: var(--border-accent); }
  .dev-info { display: flex; align-items: center; gap: 10px; flex: 1; min-width: 0; }
  .dev-icon { font-size: 22px; flex-shrink: 0; }
  .dev-meta { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
  .dev-name { font-weight: 500; font-size: 13px; }
  .dev-detail { font-size: 11px; color: var(--text-dim); }
  .dev-mount { font-size: 11px; color: var(--accent); font-family: var(--font-mono); }
  .win-badge {
    font-size: 10px;
    background: rgba(0,120,212,0.2);
    color: #60aaff;
    border: 1px solid rgba(0,120,212,0.3);
    border-radius: 4px;
    padding: 1px 5px;
    width: fit-content;
  }
  .dev-actions { display: flex; gap: 6px; flex-shrink: 0; }
  .empty { text-align: center; color: var(--text-dim); padding: 24px; }
  .tip {
    margin: 0 10px 10px;
    padding: 10px 12px;
    background: var(--accent-dim);
    border: 1px solid var(--border-accent);
    border-radius: var(--radius);
    font-size: 11px;
    color: var(--text-secondary);
    line-height: 1.6;
  }
  .tip code {
    background: var(--bg-tertiary);
    padding: 1px 5px;
    border-radius: 3px;
    font-family: var(--font-mono);
    color: var(--text-accent);
  }
  .panel-footer { padding: 10px; border-top: 1px solid var(--border); }
  .loading { padding: 24px; text-align: center; color: var(--text-dim); }
</style>
