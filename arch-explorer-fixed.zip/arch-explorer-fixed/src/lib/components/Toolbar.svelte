<script>
  import { invoke } from "@tauri-apps/api/core";
  import {
    currentPath, pathHistory, historyIndex,
    showHidden, viewMode, sortBy, sortAsc,
    searchQuery, searchFiles,
    navigateTo, navigateBack, navigateForward, navigateUp,
    loadDirectory, notify
  } from "../stores/explorer.js";

  let editingPath = false;
  let pathInput = $currentPath;
  let searchInput = "";
  let searchTimeout;

  $: pathInput = $currentPath;
  $: canBack    = $historyIndex > 0;
  $: canForward = $historyIndex < $pathHistory.length - 1;

  function onPathSubmit() {
    editingPath = false;
    navigateTo(pathInput);
  }

  function onSearchInput(e) {
    searchInput = e.target.value;
    searchQuery.set(searchInput);
    clearTimeout(searchTimeout);
    if (searchInput.trim()) {
      searchTimeout = setTimeout(() => searchFiles(searchInput), 280);
    }
  }

  function clearSearch() {
    searchInput = "";
    searchQuery.set("");
  }

  // Breadcrumb segments
  $: segments = $currentPath.split("/").filter(Boolean);

  function goToSegment(i) {
    const path = "/" + segments.slice(0, i + 1).join("/");
    navigateTo(path);
  }
</script>

<div class="toolbar glass-panel">
  <!-- Navigation buttons -->
  <div class="nav-group">
    <button class="nav-btn" disabled={!canBack}    on:click={navigateBack}    title="Back (Alt+←)">‹</button>
    <button class="nav-btn" disabled={!canForward} on:click={navigateForward} title="Forward (Alt+→)">›</button>
    <button class="nav-btn" on:click={navigateUp}  title="Up (Alt+↑)">↑</button>
    <button class="nav-btn" on:click={() => loadDirectory($currentPath)} title="Refresh (F5)">↻</button>
  </div>

  <!-- Path breadcrumb / editable input -->
  <div class="path-bar">
    {#if editingPath}
      <input
        class="path-input"
        bind:value={pathInput}
        on:blur={onPathSubmit}
        on:keydown={e => { if (e.key === "Enter") onPathSubmit(); if (e.key === "Escape") { editingPath = false; pathInput = $currentPath; } }}
        autofocus
      />
    {:else}
      <div class="breadcrumb" on:dblclick={() => editingPath = true} title="Double-click to edit">
        <span class="crumb root" on:click={() => navigateTo("/")}>◈</span>
        {#each segments as seg, i}
          <span class="crumb-sep">/</span>
          <span
            class="crumb"
            class:last={i === segments.length - 1}
            on:click={() => goToSegment(i)}
          >{seg}</span>
        {/each}
      </div>
    {/if}
  </div>

  <!-- Search -->
  <div class="search-wrap">
    <svg class="search-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
      <circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/>
    </svg>
    <input
      class="search-input"
      placeholder="Search..."
      value={searchInput}
      on:input={onSearchInput}
    />
    {#if searchInput}
      <button class="clear-btn" on:click={clearSearch}>✕</button>
    {/if}
  </div>

  <!-- View controls -->
  <div class="view-group">
    <button
      class="view-btn" class:active={$viewMode === "grid"}
      on:click={() => viewMode.set("grid")} title="Grid view"
    >▦</button>
    <button
      class="view-btn" class:active={$viewMode === "list"}
      on:click={() => viewMode.set("list")} title="List view"
    >☰</button>

    <div class="divider"></div>

    <button
      class="view-btn" title="Toggle hidden files"
      class:active={$showHidden}
      on:click={() => showHidden.update(v => !v) && loadDirectory($currentPath)}
    >👁</button>
  </div>
</div>

<style>
  .toolbar {
    height: 42px;
    display: flex;
    align-items: center;
    padding: 0 8px;
    gap: 6px;
    border-bottom: 1px solid var(--border);
    border-top: none;
    border-left: none;
    border-right: none;
    border-radius: 0;
    flex-shrink: 0;
  }

  .nav-group, .view-group {
    display: flex;
    align-items: center;
    gap: 2px;
  }

  .nav-btn {
    width: 28px;
    height: 28px;
    border-radius: var(--radius-sm);
    border: none;
    background: transparent;
    color: var(--text-secondary);
    font-size: 16px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition-fast);
  }
  .nav-btn:hover:not(:disabled) {
    background: var(--bg-hover);
    color: var(--text-primary);
  }
  .nav-btn:disabled { opacity: 0.3; cursor: default; }

  .path-bar {
    flex: 1;
    min-width: 0;
    height: 30px;
  }

  .breadcrumb {
    display: flex;
    align-items: center;
    height: 100%;
    padding: 0 8px;
    background: var(--bg-tertiary);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    overflow: hidden;
    gap: 2px;
    cursor: default;
  }

  .crumb {
    font-size: var(--font-size-sm);
    color: var(--text-secondary);
    padding: 1px 4px;
    border-radius: 4px;
    cursor: pointer;
    white-space: nowrap;
    transition: var(--transition-fast);
  }
  .crumb:hover { background: var(--bg-hover); color: var(--text-primary); }
  .crumb.last  { color: var(--text-primary); font-weight: 500; }
  .crumb.root  { color: var(--accent); font-size: 15px; }

  .crumb-sep {
    color: var(--text-dim);
    font-size: 11px;
    user-select: none;
  }

  .path-input {
    width: 100%;
    height: 100%;
    background: var(--bg-tertiary);
    border: 1px solid var(--border-accent);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    font-family: var(--font-mono);
    font-size: var(--font-size-sm);
    padding: 0 8px;
  }

  .search-wrap {
    position: relative;
    display: flex;
    align-items: center;
    width: 200px;
  }

  .search-icon {
    position: absolute;
    left: 8px;
    color: var(--text-dim);
    pointer-events: none;
  }

  .search-input {
    width: 100%;
    height: 28px;
    padding: 0 28px;
    background: var(--bg-tertiary);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    font-size: var(--font-size-sm);
  }
  .search-input:focus { border-color: var(--border-accent); }
  .search-input::placeholder { color: var(--text-dim); }

  .clear-btn {
    position: absolute;
    right: 6px;
    background: none;
    border: none;
    color: var(--text-dim);
    cursor: pointer;
    font-size: 10px;
    padding: 2px;
  }
  .clear-btn:hover { color: var(--text-primary); }

  .view-btn {
    width: 28px;
    height: 28px;
    border-radius: var(--radius-sm);
    border: none;
    background: transparent;
    color: var(--text-dim);
    cursor: pointer;
    font-size: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: var(--transition-fast);
  }
  .view-btn:hover  { background: var(--bg-hover); color: var(--text-primary); }
  .view-btn.active { background: var(--accent-dim); color: var(--accent); }

  .divider {
    width: 1px;
    height: 18px;
    background: var(--border);
    margin: 0 2px;
  }
</style>
