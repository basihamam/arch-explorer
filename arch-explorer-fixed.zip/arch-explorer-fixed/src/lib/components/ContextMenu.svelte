<script>
  // ContextMenu.svelte
  import { contextMenu, selectedPaths, currentPath,
           loadDirectory, deleteItems, runCommand,
           userCommands, notify, navigateTo } from "../stores/explorer.js";
  import { invoke } from "@tauri-apps/api/core";
  import { onMount } from "svelte";

  let menu;

  onMount(() => {
    const close = () => contextMenu.set(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", e => {
      // Only close if not our menu
      if (menu && !menu.contains(e.target)) close();
    });
    return () => {
      window.removeEventListener("click", close);
    };
  });

  $: target = $contextMenu?.target;
  $: selectedList = [...$selectedPaths];

  async function newFolder() {
    const name = prompt("Folder name:");
    if (!name) return;
    await invoke("create_dir", { path: $currentPath + "/" + name });
    await loadDirectory($currentPath);
    contextMenu.set(null);
  }

  async function newFile() {
    const name = prompt("File name:");
    if (!name) return;
    await invoke("create_file", { path: $currentPath + "/" + name });
    await loadDirectory($currentPath);
    contextMenu.set(null);
  }

  async function rename() {
    if (!target) return;
    const newName = prompt("Rename to:", target.name);
    if (!newName || newName === target.name) return;
    const newPath = target.path.replace(/[^/]+$/, newName);
    await invoke("rename_item", { oldPath: target.path, newPath });
    await loadDirectory($currentPath);
    contextMenu.set(null);
  }

  async function trash() {
    await deleteItems(selectedList.length ? selectedList : [target?.path], false);
    contextMenu.set(null);
  }

  async function deletePerma() {
    if (!confirm(`Permanently delete ${selectedList.length || 1} item(s)?`)) return;
    await deleteItems(selectedList.length ? selectedList : [target?.path], true);
    contextMenu.set(null);
  }

  function copyPath() {
    const p = target?.path || $currentPath;
    navigator.clipboard.writeText(p);
    notify("success", "Path copied");
    contextMenu.set(null);
  }

  async function runCmd(cmd) {
    await runCommand(cmd.id, target?.path);
    contextMenu.set(null);
  }

  $: contextCmds = $userCommands.filter(c => c.show_in_context_menu);
</script>

{#if $contextMenu}
  <div
    class="context-menu glass"
    style="left: {$contextMenu.x}px; top: {$contextMenu.y}px"
    bind:this={menu}
    on:click|stopPropagation
  >
    {#if target}
      <div class="ctx-label truncate">{target.name}</div>
      <div class="ctx-sep"></div>
      <button class="ctx-item" on:click={rename}>Rename</button>
      <button class="ctx-item" on:click={copyPath}>Copy Path</button>
      <button class="ctx-item" on:click={trash}>Move to Trash</button>
      <button class="ctx-item danger" on:click={deletePerma}>Delete Permanently</button>
    {:else}
      <div class="ctx-label">This folder</div>
      <div class="ctx-sep"></div>
      <button class="ctx-item" on:click={newFolder}>New Folder</button>
      <button class="ctx-item" on:click={newFile}>New File</button>
      <button class="ctx-item" on:click={copyPath}>Copy Path</button>
    {/if}

    {#if contextCmds.length > 0}
      <div class="ctx-sep"></div>
      <div class="ctx-label">Commands</div>
      {#each contextCmds as cmd}
        <button class="ctx-item cmd-item" on:click={() => runCmd(cmd)}>
          <span class="cmd-cat">{cmd.icon}</span>
          {cmd.name}
        </button>
      {/each}
    {/if}
  </div>
{/if}

<style>
  .context-menu {
    position: fixed;
    z-index: 200;
    min-width: 180px;
    border-radius: var(--radius);
    padding: 4px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
  }
  .ctx-label {
    padding: 4px 10px;
    font-size: 10px;
    color: var(--text-dim);
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    max-width: 180px;
  }
  .ctx-sep { height: 1px; background: var(--border); margin: 3px 0; }
  .ctx-item {
    display: flex; align-items: center; gap: 8px;
    width: 100%;
    padding: 6px 10px;
    border-radius: var(--radius-sm);
    border: none;
    background: none;
    color: var(--text-primary);
    font-size: 13px;
    cursor: pointer;
    text-align: left;
    transition: var(--transition-fast);
  }
  .ctx-item:hover { background: var(--bg-hover); }
  .ctx-item.danger { color: var(--danger); }
  .ctx-item.danger:hover { background: var(--danger-soft); }
  .cmd-item { color: var(--text-secondary); }
  .cmd-cat { font-size: 11px; }
</style>
