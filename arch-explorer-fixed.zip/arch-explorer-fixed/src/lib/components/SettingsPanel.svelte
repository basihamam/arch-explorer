<script>
  import { createEventDispatcher } from "svelte";
  import { theme, opacity, accentColor } from "../stores/explorer.js";

  const dispatch = createEventDispatcher();

  const PRESETS = [
    { name: "Violet Dark",  accent: "#8264ff", theme: "dark",  opacity: 0.82 },
    { name: "Cyan Night",   accent: "#00d4ff", theme: "dark",  opacity: 0.78 },
    { name: "Rose Dark",    accent: "#ff6b9d", theme: "dark",  opacity: 0.80 },
    { name: "Amber Dark",   accent: "#ffd166", theme: "dark",  opacity: 0.80 },
    { name: "Mint Light",   accent: "#00c896", theme: "light", opacity: 0.90 },
    { name: "Sakura Light", accent: "#e8748a", theme: "light", opacity: 0.88 },
    { name: "Full Dark",    accent: "#8264ff", theme: "dark",  opacity: 0.96 },
    { name: "Ghost",        accent: "#8264ff", theme: "dark",  opacity: 0.55 },
  ];

  function applyPreset(p) {
    theme.set(p.theme);
    opacity.set(p.opacity);
    accentColor.set(p.accent);
  }
</script>

<div class="overlay" on:click|self={() => dispatch("close")}>
  <div class="panel glass">
    <div class="panel-header">
      <span>Appearance Settings</span>
      <button on:click={() => dispatch("close")}>✕</button>
    </div>

    <div class="settings-body">

      <!-- Theme -->
      <section class="setting-group">
        <label class="group-label">Theme</label>
        <div class="toggle-row">
          <button class="toggle-btn" class:active={$theme === "dark"}  on:click={() => theme.set("dark")}>Dark</button>
          <button class="toggle-btn" class:active={$theme === "light"} on:click={() => theme.set("light")}>Light</button>
        </div>
      </section>

      <!-- Accent Color -->
      <section class="setting-group">
        <label class="group-label">Accent Color</label>
        <div class="color-row">
          <input type="color" bind:value={$accentColor} class="color-picker" />
          <span class="color-val">{$accentColor}</span>
          <div class="color-preview" style="background: {$accentColor}"></div>
        </div>
      </section>

      <!-- Opacity / Transparency -->
      <section class="setting-group">
        <label class="group-label">Background Opacity: {Math.round($opacity * 100)}%</label>
        <input
          type="range"
          min="0.3"
          max="0.99"
          step="0.01"
          bind:value={$opacity}
          class="slider"
        />
        <div class="opacity-labels">
          <span>Ghost</span>
          <span>Full</span>
        </div>
      </section>

      <!-- Presets -->
      <section class="setting-group">
        <label class="group-label">Presets</label>
        <div class="presets">
          {#each PRESETS as p}
            <button
              class="preset-btn"
              style="--pc: {p.accent}"
              on:click={() => applyPreset(p)}
              title={p.name}
            >
              <span class="preset-dot"></span>
              <span class="preset-name">{p.name}</span>
            </button>
          {/each}
        </div>
      </section>

      <!-- Custom CSS -->
      <section class="setting-group">
        <label class="group-label">Custom CSS Variables</label>
        <p class="hint">
          Edit <code>src/app.css</code> to change any <code>--variable</code>.
          Full control, no limits.
        </p>
      </section>
    </div>
  </div>
</div>

<style>
  .overlay {
    position: fixed; inset: 0;
    background: rgba(0,0,0,0.4);
    backdrop-filter: blur(4px);
    display: flex; align-items: center; justify-content: center;
    z-index: 100;
  }
  .panel {
    width: 420px;
    max-height: 80vh;
    border-radius: var(--radius-lg);
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }
  .panel-header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 14px 18px;
    border-bottom: 1px solid var(--border);
    font-weight: 600;
  }
  .panel-header button { background: none; border: none; color: var(--text-dim); cursor: pointer; font-size: 14px; }
  .settings-body { flex: 1; overflow-y: auto; padding: 16px; display: flex; flex-direction: column; gap: 20px; }

  .setting-group { display: flex; flex-direction: column; gap: 8px; }
  .group-label { font-size: 11px; font-weight: 600; color: var(--text-dim); text-transform: uppercase; letter-spacing: 0.08em; }

  .toggle-row { display: flex; gap: 6px; }
  .toggle-btn {
    padding: 5px 16px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    background: var(--bg-tertiary);
    color: var(--text-secondary);
    cursor: pointer;
    font-size: 13px;
    transition: var(--transition-fast);
  }
  .toggle-btn.active {
    background: var(--accent-dim);
    border-color: var(--border-accent);
    color: var(--accent);
  }

  .color-row { display: flex; align-items: center; gap: 10px; }
  .color-picker {
    width: 40px; height: 32px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    padding: 2px;
    background: var(--bg-tertiary);
    cursor: pointer;
  }
  .color-val { font-family: var(--font-mono); font-size: 12px; color: var(--text-secondary); }
  .color-preview { width: 24px; height: 24px; border-radius: 50%; }

  .slider {
    width: 100%;
    accent-color: var(--accent);
    cursor: pointer;
  }
  .opacity-labels { display: flex; justify-content: space-between; font-size: 10px; color: var(--text-dim); }

  .presets { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
  .preset-btn {
    display: flex; align-items: center; gap: 8px;
    padding: 7px 10px;
    border-radius: var(--radius-sm);
    border: 1px solid var(--border);
    background: var(--bg-tertiary);
    cursor: pointer;
    transition: var(--transition-fast);
    color: var(--text-primary);
    font-size: 12px;
  }
  .preset-btn:hover { border-color: var(--pc); background: var(--bg-hover); }
  .preset-dot { width: 10px; height: 10px; border-radius: 50%; background: var(--pc); flex-shrink: 0; }
  .preset-name { color: var(--text-secondary); }

  .hint { font-size: 11px; color: var(--text-dim); line-height: 1.6; }
  .hint code { font-family: var(--font-mono); color: var(--text-accent); background: var(--bg-tertiary); padding: 1px 4px; border-radius: 3px; }
</style>
