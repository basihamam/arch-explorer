<script>
  import { invoke } from "@tauri-apps/api/core";
  import {
    bookmarks, drives, navigateTo, currentPath,
    loadBookmarks, notify
  } from "../stores/explorer.js";

  async function addCurrentBookmark() {
    const name = prompt("Bookmark name:", $currentPath.split("/").pop() || "root");
    if (!name) return;
    await invoke("add_bookmark", { name, path: $currentPath });
    await loadBookmarks();
    notify("success", `Bookmarked: ${name}`);
  }

  async function removeBookmark(path) {
    await invoke("remove_bookmark", { path });
    await loadBookmarks();
  }
</script>

<aside class="sidebar glass-panel">
  <div class="section">
    <div class="section-header">
      <span>Bookmarks</span>
      <button class="add-btn" on:click={addCurrentBookmark} title="Bookmark current folder">+</button>
    </div>
    {#each $bookmarks as bm}
      <button
        class="sidebar-item"
        class:active={$currentPath === bm.path}
        on:click={() => navigateTo(bm.path)}
        on:contextmenu|preventDefault={() => removeBookmark(bm.path)}
        title={bm.path}
      >
        <span class="item-icon">⊹</span>
        <span class="item-label">{bm.name}</span>
      </button>
    {/each}
  </div>

  {#if $drives.length > 0}
    <div class="section">
      <div class="section-header"><span>Drives</span></div>
      {#each $drives as drv}
        <button
          class="sidebar-item"
          class:active={$currentPath.startsWith(drv.mount_point)}
          on:click={() => navigateTo(drv.mount_point)}
          title={drv.device}
        >
          <span class="item-icon">◉</span>
          <span class="item-label">{drv.name || drv.device}</span>
        </button>
      {/each}
    </div>
  {/if}
</aside>

<style>
  .sidebar {
    width: var(--sidebar-width);
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
    border-right: 1px solid var(--border);
    border-top: none; border-bottom: none; border-left: none;
    border-radius: 0;
    padding: 8px 6px;
    gap: 4px;
  }
  .section { display: flex; flex-direction: column; gap: 1px; margin-bottom: 8px; }
  .section-header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 4px 8px;
    font-size: 10px; font-weight: 700;
    color: var(--text-dim);
    text-transform: uppercase; letter-spacing: 0.1em;
  }
  .add-btn {
    background: none; border: none;
    color: var(--text-dim); cursor: pointer;
    font-size: 16px; line-height: 1; padding: 0 2px;
    transition: var(--transition-fast);
  }
  .add-btn:hover { color: var(--accent); }
  .sidebar-item {
    display: flex; align-items: center; gap: 8px;
    padding: 5px 8px;
    border-radius: var(--radius-sm);
    border: 1px solid transparent;
    background: none; color: var(--text-secondary);
    font-size: 12px; cursor: pointer; text-align: left;
    transition: var(--transition-fast); width: 100%;
    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  }
  .sidebar-item:hover { background: var(--bg-hover); color: var(--text-primary); }
  .sidebar-item.active {
    background: var(--accent-dim);
    border-color: var(--border-accent);
    color: var(--text-accent);
  }
  .item-icon { color: var(--accent); font-size: 10px; flex-shrink: 0; }
  .item-label { flex: 1; overflow: hidden; text-overflow: ellipsis; }
</style>
