<!-- StatusBar.svelte -->
<script>
  import { displayEntries, selectedPaths, currentPath, searchQuery } from "../stores/explorer.js";

  function formatSize(bytes) {
    if (!bytes) return "0 B";
    const u = ["B","KB","MB","GB"];
    let i = 0, n = bytes;
    while (n >= 1024 && i < u.length-1) { n /= 1024; i++; }
    return `${n.toFixed(i?1:0)} ${u[i]}`;
  }

  $: totalSize = $displayEntries.reduce((s, e) => s + e.size, 0);
  $: selectedCount = $selectedPaths.size;
</script>

<div class="statusbar">
  <span class="stat">{$displayEntries.length} items</span>
  {#if selectedCount > 0}
    <span class="stat selected">{selectedCount} selected</span>
  {/if}
  {#if $searchQuery}
    <span class="stat search">Search: "{$searchQuery}"</span>
  {/if}
  <span class="spacer"></span>
  <span class="stat dim">{formatSize(totalSize)}</span>
  <span class="stat path">{$currentPath}</span>
</div>

<style>
  .statusbar {
    height: var(--statusbar-height);
    display: flex;
    align-items: center;
    padding: 0 12px;
    gap: 10px;
    background: var(--bg-secondary);
    border-top: 1px solid var(--border);
    flex-shrink: 0;
    font-size: 11px;
    color: var(--text-dim);
  }
  .stat { white-space: nowrap; }
  .stat.selected { color: var(--accent); }
  .stat.search { color: var(--warning); }
  .stat.path { font-family: var(--font-mono); font-size: 10px; opacity: 0.6; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .spacer { flex: 1; }
</style>
