<script>
  import { invoke } from "@tauri-apps/api/core";
  import {
    displayEntries, viewMode, selectedPaths, currentPath,
    contextMenu, navigateTo, loadDirectory, notify,
    isLoading, loadError, searchQuery
  } from "../stores/explorer.js";

  // File type → color
  const TYPE_COLORS = {
    "inode/directory":        "#8264ff",
    "application/pdf":        "#ff5f6d",
    "image/":                 "#5aff8e",
    "video/":                 "#ffd166",
    "audio/":                 "#06d6a0",
    "text/":                  "#a8daff",
    "application/zip":        "#f4a261",
    "application/x-tar":      "#f4a261",
    "application/gzip":       "#f4a261",
    "application/javascript": "#ffd166",
    "text/x-rust":            "#ff6b35",
    "application/json":       "#ffd166",
  };

  function getColor(mime) {
    for (const [key, color] of Object.entries(TYPE_COLORS)) {
      if (mime.startsWith(key)) return color;
    }
    return "#8898aa";
  }

  function getIcon(entry) {
    if (entry.is_dir) return "📁";
    const m = entry.mime_type;
    if (m.startsWith("image/"))  return "🖼";
    if (m.startsWith("video/"))  return "🎬";
    if (m.startsWith("audio/"))  return "🎵";
    if (m.includes("pdf"))       return "📄";
    if (m.includes("zip") || m.includes("tar") || m.includes("gzip")) return "🗜";
    if (m.includes("javascript") || m.includes("json")) return "⚡";
    if (m.startsWith("text/"))   return "📝";
    // By extension
    const ext = entry.extension?.toLowerCase();
    if (ext === "rs")   return "🦀";
    if (ext === "py")   return "🐍";
    if (ext === "lua")  return "🌙";
    if (ext === "sh")   return "💲";
    if (ext === "md")   return "📖";
    if (ext === "toml") return "⚙";
    return "📄";
  }

  function formatSize(bytes) {
    if (!bytes) return "—";
    const units = ["B","KB","MB","GB","TB"];
    let i = 0, n = bytes;
    while (n >= 1024 && i < units.length - 1) { n /= 1024; i++; }
    return `${n.toFixed(i ? 1 : 0)} ${units[i]}`;
  }

  // ── Selection ─────────────────────────────────────────────
  function toggleSelect(e, path) {
    selectedPaths.update(s => {
      const next = new Set(s);
      if (e.ctrlKey) {
        if (next.has(path)) next.delete(path); else next.add(path);
      } else if (e.shiftKey) {
        const paths = $displayEntries.map(e => e.path);
        const last = [...s].pop();
        if (last) {
          const a = paths.indexOf(last);
          const b = paths.indexOf(path);
          const [lo, hi] = [Math.min(a,b), Math.max(a,b)];
          paths.slice(lo, hi + 1).forEach(p => next.add(p));
        } else {
          next.add(path);
        }
      } else {
        next.clear();
        next.add(path);
      }
      return next;
    });
  }

  function onItemClick(e, entry) {
    e.stopPropagation();
    toggleSelect(e, entry.path);
  }

  function onItemDblClick(entry) {
    if (entry.is_dir) {
      navigateTo(entry.path);
    } else {
      invoke("plugin:shell|open", { path: entry.path }).catch(() =>
        notify("error", `Cannot open: ${entry.name}`)
      );
    }
  }

  function onContextMenu(e, entry) {
    e.preventDefault();
    e.stopPropagation();
    if (!$selectedPaths.has(entry.path)) {
      selectedPaths.update(s => { const n = new Set(); n.add(entry.path); return n; });
    }
    contextMenu.set({ x: e.clientX, y: e.clientY, target: entry });
  }

  function onBgContextMenu(e) {
    e.preventDefault();
    selectedPaths.set(new Set());
    contextMenu.set({ x: e.clientX, y: e.clientY, target: null });
  }

  function onBgClick(e) {
    if (e.target === e.currentTarget) {
      selectedPaths.set(new Set());
      contextMenu.set(null);
    }
  }

  // ── Drag & drop ───────────────────────────────────────────
  let dragSource = null;

  function onDragStart(e, entry) {
    dragSource = entry;
    e.dataTransfer.effectAllowed = "move";
    e.dataTransfer.setData("text/plain", entry.path);
  }

  async function onDrop(e, targetEntry) {
    e.preventDefault();
    if (!dragSource || !targetEntry?.is_dir) return;
    if (dragSource.path === targetEntry.path) return;
    const dest = targetEntry.path + "/" + dragSource.name;
    try {
      await invoke("move_item", { src: dragSource.path, dst: dest });
      await loadDirectory($currentPath);
      notify("success", `Moved ${dragSource.name} → ${targetEntry.name}`);
    } catch (err) {
      notify("error", String(err));
    }
    dragSource = null;
  }

  // ── Selection Rectangle ───────────────────────────────────
  let fileArea;
  let selRect = null;       // { x, y, w, h } in px relative to fileArea
  let selStart = null;      // { x, y } mousedown position
  let isSelecting = false;

  function onMouseDown(e) {
    // Only on left click, not on file items, not on scrollbar
    if (e.button !== 0) return;
    if (e.target !== fileArea && e.target.closest(".grid-item, .list-row")) return;
    if (e.ctrlKey || e.shiftKey) return;

    const rect = fileArea.getBoundingClientRect();
    selStart = {
      x: e.clientX - rect.left + fileArea.scrollLeft,
      y: e.clientY - rect.top  + fileArea.scrollTop,
    };
    isSelecting = true;
    selRect = null;

    // Clear selection if clicking on empty space
    if (!e.ctrlKey) selectedPaths.set(new Set());

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup",   onMouseUp);
    e.preventDefault();
  }

  function onMouseMove(e) {
    if (!isSelecting || !selStart) return;

    const rect = fileArea.getBoundingClientRect();
    const curX = e.clientX - rect.left + fileArea.scrollLeft;
    const curY = e.clientY - rect.top  + fileArea.scrollTop;

    selRect = {
      x: Math.min(selStart.x, curX),
      y: Math.min(selStart.y, curY),
      w: Math.abs(curX - selStart.x),
      h: Math.abs(curY - selStart.y),
    };

    // Hit test: select items that overlap the rect
    if (selRect.w > 4 || selRect.h > 4) {
      const newSelected = new Set();
      const items = fileArea.querySelectorAll(".grid-item, .list-row");
      items.forEach(item => {
        const ir = item.getBoundingClientRect();
        const itemX = ir.left - rect.left + fileArea.scrollLeft;
        const itemY = ir.top  - rect.top  + fileArea.scrollTop;

        const overlaps = !(
          itemX > selRect.x + selRect.w ||
          itemX + ir.width  < selRect.x ||
          itemY > selRect.y + selRect.h ||
          itemY + ir.height < selRect.y
        );

        if (overlaps) {
          const path = item.dataset.path;
          if (path) newSelected.add(path);
        }
      });
      selectedPaths.set(newSelected);
    }
  }

  function onMouseUp() {
    isSelecting = false;
    selRect = null;
    selStart = null;
    window.removeEventListener("mousemove", onMouseMove);
    window.removeEventListener("mouseup",   onMouseUp);
  }
</script>

<!-- svelte-ignore a11y-no-static-element-interactions -->
<div
  class="file-area"
  class:grid-mode={$viewMode === "grid"}
  class:list-mode={$viewMode === "list"}
  bind:this={fileArea}
  on:click={onBgClick}
  on:contextmenu={onBgContextMenu}
  on:mousedown={onMouseDown}
>
  <!-- Selection rectangle -->
  {#if selRect && (selRect.w > 4 || selRect.h > 4)}
    <div
      class="sel-rect"
      style="left:{selRect.x}px; top:{selRect.y}px; width:{selRect.w}px; height:{selRect.h}px;"
    ></div>
  {/if}

  {#if $isLoading}
    <div class="state-msg">
      <div class="spinner"></div>
      <span>Loading...</span>
    </div>

  {:else if $loadError}
    <div class="state-msg error">
      <span style="font-size:32px">⚠</span>
      <span>{$loadError}</span>
    </div>

  {:else if $displayEntries.length === 0}
    <div class="state-msg">
      <span style="font-size:40px">◫</span>
      <span>{$searchQuery ? "No results" : "Empty folder"}</span>
    </div>

  {:else if $viewMode === "grid"}
    <div class="grid">
      {#each $displayEntries as entry (entry.path)}
        {@const selected = $selectedPaths.has(entry.path)}
        <!-- svelte-ignore a11y-no-static-element-interactions -->
        <div
          class="grid-item"
          class:selected
          data-path={entry.path}
          on:click={e => onItemClick(e, entry)}
          on:dblclick={() => onItemDblClick(entry)}
          on:contextmenu={e => onContextMenu(e, entry)}
          draggable="true"
          on:dragstart={e => onDragStart(e, entry)}
          on:dragover|preventDefault
          on:drop={e => onDrop(e, entry)}
          title={entry.path}
        >
          <div class="grid-icon" style="color: {getColor(entry.mime_type)}">
            {getIcon(entry)}
          </div>
          <div class="grid-name truncate">{entry.name}</div>
          {#if !entry.is_dir}
            <div class="grid-size">{formatSize(entry.size)}</div>
          {/if}
        </div>
      {/each}
    </div>

  {:else}
    <!-- List view -->
    <div class="list">
      <div class="list-header">
        <span class="col-name">Name</span>
        <span class="col-size">Size</span>
        <span class="col-date">Modified</span>
        <span class="col-perms">Permissions</span>
      </div>
      {#each $displayEntries as entry (entry.path)}
        {@const selected = $selectedPaths.has(entry.path)}
        <!-- svelte-ignore a11y-no-static-element-interactions -->
        <div
          class="list-row"
          class:selected
          data-path={entry.path}
          on:click={e => onItemClick(e, entry)}
          on:dblclick={() => onItemDblClick(entry)}
          on:contextmenu={e => onContextMenu(e, entry)}
          draggable="true"
          on:dragstart={e => onDragStart(e, entry)}
          on:dragover|preventDefault
          on:drop={e => onDrop(e, entry)}
        >
          <span class="col-name">
            <span class="row-icon" style="color:{getColor(entry.mime_type)}">{getIcon(entry)}</span>
            <span class="truncate" title={entry.path}>{entry.name}</span>
            {#if entry.is_symlink}<span class="symlink-badge">⤷</span>{/if}
          </span>
          <span class="col-size text-dim">{entry.is_dir ? "—" : formatSize(entry.size)}</span>
          <span class="col-date text-dim">{entry.modified}</span>
          <span class="col-perms text-mono">{entry.permissions}</span>
        </div>
      {/each}
    </div>
  {/if}
</div>

<style>
  .file-area {
    flex: 1;
    overflow-y: auto;
    overflow-x: hidden;
    padding: 8px;
    position: relative;
    /* Yazı seçimini engelle */
    user-select: none;
    -webkit-user-select: none;
  }

  .state-msg {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 12px;
    height: 100%;
    color: var(--text-dim);
    font-size: 14px;
    user-select: none;
  }
  .state-msg.error { color: var(--danger); }

  /* ── Selection Rectangle ── */
  .sel-rect {
    position: absolute;
    pointer-events: none;
    background: rgba(130, 100, 255, 0.12);
    border: 1px solid rgba(130, 100, 255, 0.5);
    border-radius: 4px;
    z-index: 50;
  }

  /* ── Grid ── */
  .grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(90px, 1fr));
    gap: 4px;
  }

  .grid-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    padding: 8px 4px 6px;
    border-radius: var(--radius);
    border: 1px solid transparent;
    cursor: pointer;
    transition: var(--transition-fast);
    text-align: center;
    user-select: none;
  }
  .grid-item:hover {
    background: var(--bg-hover);
    border-color: var(--border);
  }
  .grid-item.selected {
    background: var(--bg-selected);
    border-color: var(--border-accent);
  }

  .grid-icon { font-size: 32px; line-height: 1; user-select: none; }
  .grid-name { font-size: 11px; color: var(--text-primary); width: 100%; user-select: none; }
  .grid-size { font-size: 10px; color: var(--text-dim); user-select: none; }

  /* ── List ── */
  .list { display: flex; flex-direction: column; }

  .list-header {
    display: grid;
    grid-template-columns: 1fr 80px 140px 100px;
    padding: 4px 8px;
    font-size: 11px;
    color: var(--text-dim);
    border-bottom: 1px solid var(--border);
    user-select: none;
    position: sticky;
    top: 0;
    background: var(--bg-secondary);
    z-index: 1;
  }

  .list-row {
    display: grid;
    grid-template-columns: 1fr 80px 140px 100px;
    align-items: center;
    padding: 4px 8px;
    border-radius: var(--radius-sm);
    border: 1px solid transparent;
    cursor: pointer;
    transition: var(--transition-fast);
    user-select: none;
  }
  .list-row:hover    { background: var(--bg-hover); }
  .list-row.selected { background: var(--bg-selected); border-color: var(--border-accent); }

  .col-name {
    display: flex;
    align-items: center;
    gap: 8px;
    min-width: 0;
    font-size: var(--font-size-base);
    user-select: none;
  }
  .col-size, .col-date, .col-perms {
    font-size: var(--font-size-sm);
    user-select: none;
  }
  .col-perms { font-family: var(--font-mono); font-size: 10px; }
  .row-icon { font-size: 16px; flex-shrink: 0; }
  .symlink-badge { color: var(--accent); font-size: 12px; }

  /* Spinner */
  .spinner {
    width: 28px; height: 28px;
    border: 2px solid var(--border);
    border-top-color: var(--accent);
    border-radius: 50%;
    animation: spin 0.7s linear infinite;
  }
  @keyframes spin { to { transform: rotate(360deg); } }
</style>
